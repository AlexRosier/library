package com.axxes.persistence.dao;

import org.springframework.stereotype.Component;

@Component
public class TagDao {
}