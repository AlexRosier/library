package com.axxes.persistence.dao;

import com.axxes.persistence.domain.Suggestion;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class SuggestionDao {

    public void createSuggestion(Suggestion suggestion) {

    }

    public List<Suggestion> getAllSuggestion(Object p0) {
        return null;
    }
}